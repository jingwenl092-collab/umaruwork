# 项目记忆 — 日译训练场

## 项目定位
中日翻译/口译「技能训练」网页应用（用户已确认）。练翻译用，不是实时翻译工具。

## 第一版范围（已确认）
- 四页面：首页（方向/难度/场景选择 + 概览）、练习页（核心）、练习报告页、历史记录页
- 六步练习循环：出题 → 语音口译/打字输入 → 确认识别文本 → AI 讲评 → 反馈卡片 → 下一句；满 10 句进报告页
- AI 反馈**不打数字分数**（用户明确要求去掉）：改为「总评 + 做得好 + 可以更好 + 参考译文」的讲评式反馈
- 数据存浏览器本地（localStorage，key `riyi_log_v1`），无账户系统
- UI 风格：薄荷绿护眼色系（--bg #ECF2EA / --accent #47835F），低对比、大留白、圆角

## 技术约定与踩坑
- 已发布上线：appId `wbapp_UKLmxnV7CClwQetku66ood`，代码在 riyi-trainer/，入口 index.html
- 线上分享链接：https://riyi-trainer.app.workbuddy.host/ （静态站点；发布必须与云服务保留域名一致，否则 AI 讲评会因 Origin 不匹配而失败）
- 云端 LLM **必须显式选模型**：取 models.list() 第一个（auto）会落到思考型模型，单次讲评 110 秒。首选 deepseek-v4-flash（约 2 秒），备选 hunyuan-chat；glm 系列慢且会输出 ```json 围栏（解析已兼容）
- 语音识别用浏览器 Web Speech API，语种按方向切换（中→日识别 ja-JP，日→中识别 zh-CN）；不支持的浏览器自动降级打字输入
- 素材库内置 240 组句对，按难度（初/中/高）×场景（日常生活、旅行、商务、校园）分类，每格 20 句
- 题库按场景拆成 4 个文件（data-daily/travel/business/campus.js），data.js 是归一化器；数据用 `{汉字|读音}` 标记，派生 `ja`（纯文本，朗读/AI 用）和 `furi`（注音，渲染用）
- 改题库后必须跑 `node js/check-data.js` 校验（句数/分组/标记配对/去重/日常场景重敬语）
- 振假名：`app.js` 的 `furiToHtml()` 把 `{汉字|读音}` → `<ruby>`；只在显示层注音，朗读和 AI 讲评仍用纯文本
- TTS 踩坑：设备缺对应语种语音包时，`speechSynthesis.speak()` 会**静默失败**（不发声也不报错），用户感受就是"点了没反应"。必须自己用 `getVoices()` 检测并给出可见提示（含各系统安装语音包指引），不能只调 speak()
- 改完本地代码**不会自动同步到线上**，需重新发布（会覆盖线上现有内容），且每轮都要用户明确同意
- 本会话跑 git 远程命令**必须绕开代理**，最稳写法（env 清空 + git 配置层面再清一次）：
  `http_proxy= https_proxy= HTTP_PROXY= HTTPS_PROXY= ALL_PROXY= all_proxy= git -c http.proxy= -c https.proxy= push`
  只清 env 有时仍会被代理拦截；GitHub 连接还会间歇性 `Connection was reset`，失败重试即可
- 写重试循环时别用 `cmd | tail -3 && break`——`tail` 退出码恒为 0，失败也会 break；要判 `PIPESTATUS[0]`
- Git 远程命令在本会话里**必须绕过代理**才能连通 GitHub（环境注入的 127.0.0.1:2325 代理对 git 的 CONNECT 返回 502）：
  `http_proxy= https_proxy= HTTP_PROXY= HTTPS_PROXY= ALL_PROXY= all_proxy= git push`
- 远程仓库：https://github.com/jingwenl092-collab/umaruwork （main 分支）

## 暂不做（后续版本）
自定义素材导入、账户系统、错题本/间隔重复、发音评测、单词语法教学
